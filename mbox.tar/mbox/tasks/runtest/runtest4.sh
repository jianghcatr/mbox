#!/bin/bash
run_time=`date`
echo "test4 "${run_time} >>/home/collect/runtest.txt
