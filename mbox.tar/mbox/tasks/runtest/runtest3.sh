#!/bin/bash
run_time=`date`
echo "test3 "${run_time} >>/home/collect/runtest.txt
