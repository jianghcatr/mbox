#!/bin/bash
run_time=`date`
echo "test2 "${run_time} >>/home/collect/runtest.txt
