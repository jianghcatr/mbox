#!/bin/bash
run_time=`date`
echo "test5 "${run_time} >>/home/collect/runtest.txt
