#!/bin/bash
run_time=`date`
echo "test1 "${run_time} >>/home/collect/runtest.txt
sleep 2

